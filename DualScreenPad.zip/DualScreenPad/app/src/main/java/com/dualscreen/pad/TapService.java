package com.dualscreen.pad;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;

/** Simule des appuis sur l'écran externe (là où tourne le jeu). */
public class TapService extends AccessibilityService {

    public static TapService instance;

    @Override
    protected void onServiceConnected() {
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    /** nx, ny entre 0 et 1 : position relative sur l'écran cible. */
    public void tap(float nx, float ny, int displayId) {
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display d = dm.getDisplay(displayId);
        if (d == null) return;
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);

        Path p = new Path();
        p.moveTo(nx * m.widthPixels, ny * m.heightPixels);

        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, 40));
        if (Build.VERSION.SDK_INT >= 32) {
            b.setDisplayId(displayId);
        }
        dispatchGesture(b.build(), null, null);
    }
}
