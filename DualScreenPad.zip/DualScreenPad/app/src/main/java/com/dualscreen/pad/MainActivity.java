package com.dualscreen.pad;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Display;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    private final List<ResolveInfo> apps = new ArrayList<>();
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 32);

        TextView title = new TextView(this);
        title.setText("DualScreen Pad");
        title.setTextSize(24);
        root.addView(title);

        status = new TextView(this);
        root.addView(status);

        Button access = new Button(this);
        access.setText("1. Activer le service d'accessibilité");
        access.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        TextView hint = new TextView(this);
        hint.setText("2. Choisis le jeu (il s'ouvrira sur le grand écran) :");
        root.addView(hint);

        ListView list = new ListView(this);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        apps.addAll(pm.queryIntentActivities(q, 0));
        Collections.sort(apps, new ResolveInfo.DisplayNameComparator(pm));

        List<String> names = new ArrayList<>();
        for (ResolveInfo r : apps) names.add(r.loadLabel(pm).toString());
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names));

        list.setOnItemClickListener((p, v, pos, id) ->
                launchGame(apps.get(pos).activityInfo.packageName));
    }

    @Override
    protected void onResume() {
        super.onResume();
        int ext = externalDisplayId();
        String s = (ext < 0 ? "❌ Aucun grand écran détecté" : "✅ Grand écran détecté (id " + ext + ")")
                + "\n" + (TapService.instance != null ? "✅ Service actif" : "❌ Service inactif");
        status.setText(s);
    }

    private int externalDisplayId() {
        DisplayManager dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        for (Display d : dm.getDisplays()) {
            if (d.getDisplayId() != Display.DEFAULT_DISPLAY) return d.getDisplayId();
        }
        return -1;
    }

    private void launchGame(String pkg) {
        int ext = externalDisplayId();
        if (ext < 0) {
            Toast.makeText(this, "Branche / active le grand écran d'abord", Toast.LENGTH_LONG).show();
            return;
        }
        Intent game = getPackageManager().getLaunchIntentForPackage(pkg);
        if (game == null) return;
        game.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        ActivityOptions o = ActivityOptions.makeBasic();
        o.setLaunchDisplayId(ext);
        try {
            startActivity(game, o.toBundle());
        } catch (Exception e) {
            Toast.makeText(this, "Lancement impossible : " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        new Handler().postDelayed(() -> {
            Intent c = new Intent(this, ControllerActivity.class);
            c.putExtra("display", ext);
            startActivity(c);
        }, 1200);
    }
}
