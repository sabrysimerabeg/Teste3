package com.dualscreen.pad;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Écran du téléphone = manette.
 * Chaque bouton est placé à la même position RELATIVE que la zone à toucher sur le grand écran.
 */
public class ControllerActivity extends Activity {

    private int targetDisplay;
    private boolean edit = true;
    private final List<float[]> buttons = new ArrayList<>(); // {nx, ny}
    private final Handler handler = new Handler();
    private SharedPreferences prefs;
    private PadView pad;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        targetDisplay = getIntent().getIntExtra("display", 1);
        prefs = getSharedPreferences("pad", Context.MODE_PRIVATE);
        load();

        FrameLayout root = new FrameLayout(this);
        pad = new PadView(this);
        root.addView(pad);

        Button toggle = new Button(this);
        toggle.setText("Mode : ÉDITION");
        toggle.setOnClickListener(v -> {
            edit = !edit;
            toggle.setText(edit ? "Mode : ÉDITION" : "Mode : JEU");
            if (edit) Toast.makeText(this,
                    "Touche vide = ajouter · glisser = déplacer · toucher un bouton = supprimer",
                    Toast.LENGTH_LONG).show();
            else save();
            pad.invalidate();
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.gravity = android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL;
        root.addView(toggle, lp);
        setContentView(root);
    }

    private void load() {
        String s = prefs.getString("buttons", "");
        for (String p : s.split(";")) {
            String[] xy = p.split(",");
            if (xy.length == 2) {
                try { buttons.add(new float[]{Float.parseFloat(xy[0]), Float.parseFloat(xy[1])}); }
                catch (NumberFormatException ignored) { }
            }
        }
    }

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (float[] f : buttons) sb.append(f[0]).append(',').append(f[1]).append(';');
        prefs.edit().putString("buttons", sb.toString()).apply();
    }

    private void tap(float[] btn) {
        TapService s = TapService.instance;
        if (s != null) s.tap(btn[0], btn[1], targetDisplay);
    }

    class PadView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float radius = 70f;
        private final Map<Integer, float[]> active = new HashMap<>();
        private final Map<Integer, Runnable> repeats = new HashMap<>();
        private float[] dragged;
        private boolean moved;

        PadView(Context c) {
            super(c);
            setBackgroundColor(Color.BLACK);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(4);
            line.setColor(Color.WHITE);
        }

        private float[] hit(float x, float y) {
            for (float[] f : buttons) {
                float dx = f[0] * getWidth() - x, dy = f[1] * getHeight() - y;
                if (dx * dx + dy * dy <= radius * radius * 1.5f) return f;
            }
            return null;
        }

        @Override
        protected void onDraw(Canvas c) {
            for (float[] f : buttons) {
                boolean on = active.containsValue(f);
                fill.setColor(on ? Color.argb(200, 80, 200, 120) : Color.argb(120, 255, 255, 255));
                c.drawCircle(f[0] * getWidth(), f[1] * getHeight(), radius, fill);
                c.drawCircle(f[0] * getWidth(), f[1] * getHeight(), radius, line);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int idx = e.getActionIndex();
            int id = e.getPointerId(idx);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN: {
                    float x = e.getX(idx), y = e.getY(idx);
                    float[] b = hit(x, y);
                    if (edit) {
                        dragged = b;
                        moved = false;
                        if (b == null) {
                            buttons.add(new float[]{x / getWidth(), y / getHeight()});
                            save();
                        }
                    } else if (b != null) {
                        active.put(id, b);
                        tap(b);
                        Runnable r = new Runnable() {
                            @Override public void run() {
                                if (active.containsKey(id)) { tap(b); handler.postDelayed(this, 90); }
                            }
                        };
                        repeats.put(id, r);
                        handler.postDelayed(r, 90);
                    }
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_MOVE:
                    if (edit && dragged != null) {
                        dragged[0] = Math.max(0, Math.min(1, e.getX() / getWidth()));
                        dragged[1] = Math.max(0, Math.min(1, e.getY() / getHeight()));
                        moved = true;
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (edit && dragged != null) {
                        if (!moved) buttons.remove(dragged); // simple toucher = supprimer
                        dragged = null;
                        save();
                    }
                    Runnable r = repeats.remove(id);
                    if (r != null) handler.removeCallbacks(r);
                    active.remove(id);
                    invalidate();
                    return true;
            }
            return true;
        }
    }
}
